"use client"

import { useState, useEffect } from "react"
import "./App.css"
import Header from "./components/Header"
import Hero from "./components/Hero"
import About from "./components/About"
import Skills from "./components/Skills"
// import Projects from "./components/Projects"
import Journey from "./components/Journey"
import Contact from "./components/Contact"
import Footer from "./components/Footer"

function App() {
  const [darkMode, setDarkMode] = useState(true)

  useEffect(() => {
    document.body.className = darkMode ? "dark-mode" : "light-mode"
  }, [darkMode])

  return (
    <div className="app">
      <Header darkMode={darkMode} setDarkMode={setDarkMode} />
      <main>
        <Hero />
        <About />
        <Skills />
        {/* Sección de Proyectos eliminada */}
        <Journey />
        <Contact />
      </main>
      <Footer />
    </div>
  )
}

export default App
