import "./Skills.css"
import {
  FaPython,
  FaJsSquare,
  FaJava,
  FaHtml5,
  FaCss3Alt,
  FaDatabase,
  FaReact,
  FaAngular,
  FaAws,
  FaLinux,
} from "react-icons/fa"
import {
  SiTypescript,
  SiCplusplus,
  SiFlask,
  SiDjango,
  SiMysql,
  SiPostgresql,
} from "react-icons/si"

const Skills = () => {
  const skillCategories = [
    {
      title: "Lenguajes de Programación",
      skills: [
        { name: "Python", icon: <FaPython size={28} color="#3776AB" /> },
        { name: "JavaScript", icon: <FaJsSquare size={28} color="#F7DF1E" /> },
        { name: "TypeScript", icon: <SiTypescript size={28} color="#3178C6" /> },
        { name: "Java", icon: <FaJava size={28} color="#ED8B00" /> },
        { name: "C/C++", icon: <SiCplusplus size={28} color="#00599C" /> },
        { name: "HTML", icon: <FaHtml5 size={28} color="#E34F26" /> },
        { name: "CSS", icon: <FaCss3Alt size={28} color="#1572B6" /> },
        { name: "SQL", icon: <FaDatabase size={28} color="#4479A1" /> },
      ],
    },
    {
      title: "Tecnologías & Frameworks",
      skills: [
        { name: "React.js", icon: <FaReact size={28} color="#61DAFB" /> },
        { name: "React Native", icon: <FaReact size={28} color="#61DAFB" /> },
        { name: "Angular", icon: <FaAngular size={28} color="#DD0031" /> },
        { name: "Flask", icon: <SiFlask size={28} color="#FFFFFF" /> },
        { name: "Django", icon: <SiDjango size={28} color="#092E20" /> },
        { name: "MySQL", icon: <SiMysql size={28} color="#4479A1" /> },
        { name: "PostgreSQL", icon: <SiPostgresql size={28} color="#336791" /> },
        { name: "SQL Server", icon: <FaDatabase size={28} color="#CC2927" /> }, 
        { name: "AWS", icon: <FaAws size={28} color="#FF9900" /> },
        { name: "Linux", icon: <FaLinux size={28} color="#FCC624" /> },
      ],
    },
  ]

  return (
    <section id="skills" className="skills">
      <h2 className="section-title">Mis Habilidades</h2>
      <div className="skills-content">
        <p className="skills-intro">
          A lo largo de mi formación y experiencia profesional, he adquirido conocimientos en diversas tecnologías y
          lenguajes de programación que me permiten desarrollar soluciones completas y eficientes.
        </p>

        <div className="skills-grid">
          {skillCategories.map((category, index) => (
            <div key={index} className="skill-category">
              <h3>{category.title}</h3>
              <div className="skill-icons">
                {category.skills.map((skill, skillIndex) => (
                  <div key={skillIndex} className="skill-item">
                    <div className="skill-icon">{skill.icon}</div>
                    <span className="skill-name">{skill.name}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="why-choose-me">
          <h3>¿Por qué trabajar conmigo?</h3>
          <div className="features-grid">
            <div className="feature-item">
              <div className="feature-icon">🚀</div>
              <h4>Desarrollo Eficiente</h4>
              <p>Optimizo el código para obtener el mejor rendimiento posible en todas las plataformas.</p>
            </div>
            <div className="feature-item">
              <div className="feature-icon">🔍</div>
              <h4>Atención al Detalle</h4>
              <p>Me enfoco en los pequeños detalles que hacen que un producto pase de bueno a excelente.</p>
            </div>
            <div className="feature-item">
              <div className="feature-icon">💡</div>
              <h4>Soluciones Creativas</h4>
              <p>Busco enfoques innovadores para resolver problemas complejos de manera elegante.</p>
            </div>
            <div className="feature-item">
              <div className="feature-icon">🔄</div>
              <h4>Adaptabilidad</h4>
              <p>Me adapto rápidamente a nuevas tecnologías y metodologías de trabajo.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Skills
