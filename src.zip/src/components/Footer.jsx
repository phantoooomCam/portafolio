import "./Footer.css"

const Footer = () => {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="footer-top">
          <div className="footer-info">
            <h3>Diego Flores</h3>
            <p>Ingeniero en Informática & Desarrollador Full Stack</p>

            <div className="footer-social-section">
              <h4>Redes Sociales</h4>
              <div className="social-buttons">
                <a
                  href="https://github.com/phantoooomCam"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="social-button"
                >
                  GitHub
                </a>
                <a
                  href="https://linkedin.com/in/diego-camarillo-20a4a420a"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="social-button"
                >
                  LinkedIn
                </a>
              </div>
            </div>
          </div>

          <div className="footer-sections">
            <div className="footer-nav">
              <h4>Navegación</h4>
              <ul>
                <li>
                  <a href="#home">Inicio</a>
                </li>
                <li>
                  <a href="#about">Sobre Mí</a>
                </li>
                <li>
                  <a href="#skills">Habilidades</a>
                </li>
                <li>
                  <a href="#projects">Proyectos</a>
                </li>
                <li>
                  <a href="#journey">Trayectoria</a>
                </li>
                <li>
                  <a href="#contact">Contacto</a>
                </li>
              </ul>
            </div>

            <div className="footer-contact">
              <h4>Contacto</h4>
              <p>bigocam123@gmail.com</p>
              <p>+52 55-71-91-58-54</p>
            </div>

            <div className="footer-social">
              <h4>Redes Sociales</h4>
              <ul>
                <li>
                  <a href="https://github.com/phantoooomCam" target="_blank" rel="noopener noreferrer">
                    GitHub
                  </a>
                </li>
                <li>
                  <a href="https://linkedin.com/in/diego-camarillo-20a4a420a" target="_blank" rel="noopener noreferrer">
                    LinkedIn
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="footer-bottom">
          <p>&copy; {currentYear} Diego Flores Camarillo. Todos los derechos reservados.</p>
        </div>
      </div>
    </footer>
  )
}

export default Footer
