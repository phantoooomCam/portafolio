import "./About.css"

const About = () => {
  return (
    <section id="about" className="about">
      <h2 className="section-title">Sobre Mí</h2>
      <div className="about-content">
        <div className="about-text">
          <p>
            Soy un Ingeniero en Informática con experiencia en desarrollo web y aplicaciones. Actualmente trabajo en R&R
            CONSULTANCY & SAFETY SERVICES, donde he desarrollado servicios web para gestión de archivos, casos y
            herramientas de inteligencia.
          </p>
          <p>
            Mi enfoque combina un sólido conocimiento técnico con una pasión por crear soluciones elegantes y
            eficientes. Me especializo en el desarrollo full stack, utilizando tecnologías como React, Python y bases de
            datos SQL.
          </p>
          <p>
            Estoy constantemente aprendiendo y mejorando mis habilidades para mantenerme al día con las últimas
            tendencias y tecnologías en el campo del desarrollo.
          </p>
        </div>
        <div className="about-info">
          <div className="info-item">
            <h3>Educación</h3>
            <div className="education-item">
              <h4>Ingeniería en Informática</h4>
              <p>
                Unidad Profesional Interdisciplinaria de Ingeniería y Ciencias Sociales y Administrativas – IPN UPIICSA
              </p>
              <p className="date">Presente</p>
            </div>
            <div className="education-item">
              <h4>Técnico en Telecomunicaciones</h4>
              <p>Centro de Estudios Científicos y Tecnológicos - IPN</p>
              <p className="date">2018 - 2021</p>
            </div>
          </div>
          <div className="info-item">
            <h3>Contacto</h3>
            <ul className="contact-list">
              <li>
                <span className="contact-label">Email:</span>
                <a href="mailto:bigocam123@gmail.com">bigocam123@gmail.com</a>
              </li>
              <li>
                <span className="contact-label">GitHub:</span>
                <a href="https://github.com/phantoooomCam" target="_blank" rel="noopener noreferrer">
                  github.com/phantoooomCam
                </a>
              </li>
              <li>
                <span className="contact-label">LinkedIn:</span>
                <a href="https://linkedin.com/in/diego-camarillo-20a4a420a" target="_blank" rel="noopener noreferrer">
                  linkedin.com/in/diego-camarillo-20a4a420a
                </a>
              </li>
              <li>
                <span className="contact-label">Teléfono:</span>
                <a href="tel:+525571915854">+52 55-71-91-58-54</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}

export default About
