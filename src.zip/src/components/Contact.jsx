import "./Contact.css"
import { Mail, GitlabIcon as GitHub, Linkedin, Phone } from "lucide-react"

const Contact = () => {
  return (
    <section id="contact" className="contact">
      <h2 className="section-title">Contacto</h2>

      <div className="contact-container">
        <div className="contact-info">
          <h3>¡Hablemos!</h3>
          <p>
            Estoy interesado en oportunidades de trabajo freelance o posiciones a tiempo completo. Si tienes alguna
            pregunta o propuesta, no dudes en contactarme a través de cualquiera de estos medios.
          </p>

          <div className="contact-methods">
            <div className="contact-method">
              <div className="contact-icon">
                <Mail size={24} />
              </div>
              <div className="contact-details">
                <h4>Email</h4>
                <a href="mailto:bigocam123@gmail.com">bigocam123@gmail.com</a>
              </div>
            </div>

            <div className="contact-method">
              <div className="contact-icon">
                <Phone size={24} />
              </div>
              <div className="contact-details">
                <h4>Teléfono</h4>
                <a href="tel:+525571915854">+52 55-71-91-58-54</a>
              </div>
            </div>

            <div className="contact-method">
              <div className="contact-icon">
                <GitHub size={24} />
              </div>
              <div className="contact-details">
                <h4>GitHub</h4>
                <a href="https://github.com/phantoooomCam" target="_blank" rel="noopener noreferrer">
                  github.com/phantoooomCam
                </a>
              </div>
            </div>

            <div className="contact-method">
              <div className="contact-icon">
                <Linkedin size={24} />
              </div>
              <div className="contact-details">
                <h4>LinkedIn</h4>
                <a href="https://linkedin.com/in/diego-camarillo-20a4a420a" target="_blank" rel="noopener noreferrer">
                  linkedin.com/in/diego-camarillo-20a4a420a
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Contact
