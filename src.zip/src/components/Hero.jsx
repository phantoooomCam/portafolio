import "./Hero.css"
import perfilImg from "../assets/libro.png" // Ajusta el nombre si es diferente

const Hero = () => {
  return (
    <section id="home" className="hero">
      <div className="hero-container">
        <div className="hero-content">
          <h1>Diego Flores Camarillo</h1>
          <p className="hero-subtitle">Ingeniero en Informática & Desarrollador Full Stack</p>
          <p className="hero-description">
            Desarrollo soluciones web y aplicaciones con tecnologías modernas que combinan diseño atractivo con
            funcionalidad robusta.
          </p>
          <div className="hero-buttons">
            <a href="#projects" className="btn">
              Ver Proyectos
            </a>
            <a href="#contact" className="btn btn-outline">
              Contactar
            </a>
          </div>
        </div>
        <div className="hero-image">
          <img src={perfilImg} alt="Diego Flores" className="profile-image" />
        </div>
      </div>
    </section>
  )
}

export default Hero
