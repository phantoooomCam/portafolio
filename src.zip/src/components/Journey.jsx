import "./Journey.css"

const Journey = () => {
  const journeyItems = [
    {
      year: "Presente",
      title: "R&R CONSULTANCY & SAFETY SERVICES",
      description:
        "Desarrollo de un servicio web para gestión de archivos, casos y herramientas de inteligencia, con frontend en React, backend en Python y una API en C#, utilizando PostgreSQL como base de datos para un almacenamiento eficiente.",
    },
    {
      year: "2024",
      title: "Desarrollo de UPII-Market",
      description:
        "Aplicación de entrega de comida desarrollada con HTML, CSS, JavaScript, Python, Flask y SQL Server.",
    },
    {
      year: "2024",
      title: "Desarrollo de School Management Application",
      description:
        "Aplicación de gestión escolar que permite la interacción entre estudiantes y profesores a través de una interfaz web responsiva.",
    },
    {
      year: "2023",
      title: "Desarrollo de U-Theatre",
      description:
        "Aplicación de gestión de teatro que administra obras, horarios y venta de boletos a través de una interfaz web responsiva.",
    },
    {
      year: "2023",
      title: "Desarrollo de BankCore",
      description:
        "Aplicación de escritorio para la gestión de entidades bancarias, permitiendo la administración de clientes, cuentas, etc.",
    },
    {
      year: "2022",
      title: "Desarrollo de Client/Server Messaging",
      description: "Programa de mensajería entre cliente y servidor utilizando sockets de Python.",
    },
  ]

  return (
    <section id="journey" className="journey">
      <h2 className="section-title">Mi Trayectoria</h2>

      <div className="timeline">
        {journeyItems.map((item, index) => (
          <div key={index} className={`timeline-item ${index % 2 === 0 ? "left" : "right"}`}>
            <div className="timeline-content">
              <div className="timeline-year">{item.year}</div>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}

export default Journey
